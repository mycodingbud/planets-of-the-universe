---
title: Terrestrial
category: planet-type
folder: Terrestrial
---

A Terrestrial planet is .....